import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'
import './MCQs.css'
import Button from '@mui/material/Button';
import StyledTextarea from '../../components/MCQs/styledTextarea'
import QueAndAnsCard from '../../components/MCQs/QueAndAnsCard'
import Loading from '../../components/MCQs/Loading'


const QueAndAnsPairPage = () => {
  const [context, setContext] = useState('')
  const [queAndAnsPair, setQueAndAnsPair] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [generateButton, setGenerateButton] = useState(false)
  const [isQueAndAnsPairGenerated, setIsQueAndAnsPairGenerated] = useState(false)

  const handleContext = (e) => {
    setContext(e.target.value)
  }

  useEffect(() => {
    if (generateButton) {
      console.log(context)
      axios.post('http://127.0.0.1:8000/qanda/', {
        context: context,
        number: 5
      })
        .then((res) => {
          console.log(res)
          setQueAndAnsPair(res.data)
          setGenerateButton(false)
          setIsLoading(false)
        })
        .catch((err) => {
          console.log(err)
          setIsLoading(false)
        })
    }
  }, [generateButton, context])

  useEffect(() => {
    if(queAndAnsPair.length === 0){
        setIsQueAndAnsPairGenerated(false)
    }else{
      setIsQueAndAnsPairGenerated(true)
    }
  }, [queAndAnsPair])

  const handleSubmit = async () => {
    console.log('done')
    setGenerateButton(true)
    setIsQueAndAnsPairGenerated(false)
    setIsLoading(true)
  }


  return (
    <div className="container" >
      <div className="left-section">
        <h2 style={{marginLeft:'20px',}}>Question and answer pair generation</h2>
        <div style={{display:"flex", justifyContent:"center"}}>
          <StyledTextarea
            aria-label="context"
            minRows={15}
            maxRows={15}
            placeholder="Please type or past your context here..."
            style={{ resize:'vertical', fontSize:'20px'}}
            onChange={handleContext}
          />
        </div>
        <div style={{paddingTop:'10px', display:'flex', justifyContent:'center', paddingBottom:'100px'}}>
            <Button variant="contained"
            style={{width:'90%', borderRadius:'12px 12px 0px 12px', textTransform:'capitalize', fontSize:'20px'}}
              onClick={handleSubmit}>
                Generate
            </Button>
          </div>
      </div>
      <div className="right-section">
        {isLoading?(<Loading/>):(<QueAndAnsCard queAndAnsPair = {queAndAnsPair}
        isQueAndAnsPairGenerated = {isQueAndAnsPairGenerated}
        setQueAndAnsPair = {setQueAndAnsPair} />)}
      </div>

    </div>
  )
}

export default QueAndAnsPairPage
