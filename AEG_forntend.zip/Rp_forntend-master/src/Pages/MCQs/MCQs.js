import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'
import './MCQs.css'
import Button from '@mui/material/Button';
import StyledTextarea from '../../components/MCQs/styledTextarea'
import MCQsCard from '../../components/MCQs/MCQsCard'
import QueAndAnsCard from '../../components/MCQs/QueAndAnsCard'
import Loading from '../../components/MCQs/Loading'
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Box from '@mui/material/Box';
import { Typography } from '@mui/material'



const MCQs = () => {
  const [context, setContext] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [generatedMCQs, setGeneratedMCQs] = useState([])
  const [queAndAnsPair, setQueAndAnsPair] = useState([])
  const [generateButton, setGenerateButton] = useState(false)
  const [isMcqsGenerated, setIsMcqsGenerated] = useState(false)
  const [isQueAndAnsPairGenerated, setIsQueAndAnsPairGenerated] = useState(false)
  const [count, setCount] = useState('');
  const [questionType, setQuestionType] = useState('MCQ');
  const [currentDataType, setCurrentDataType] = useState('')


  const handleContext = (e) => {
    setContext(e.target.value)
  }

  useEffect(() => {
    if (generateButton) {
      console.log(context)
      console.log(parseInt(count))
      console.log(questionType)
      if (questionType === 'MCQ') {
        axios.post('http://127.0.0.1:8000/mcqs/', {
          context: context,
          number: parseInt(count)
        })
          .then((res) => {
            const cleanedGeneratedMCQs = res.data.map(mcq => {
              const uniqueDistractors = new Set();

              const cleanedDistractors = mcq.distractors.map(distractor => {
                let cleanedDistractor = distractor.replace(/^[A-Z][).]/i, '').trim().toLowerCase();
                const commaIndex = cleanedDistractor.indexOf(',');
                if (commaIndex !== -1) {
                  cleanedDistractor = cleanedDistractor.substring(0, commaIndex).trim();
                }
                return cleanedDistractor;
              }).filter(distractor => {
                if (!uniqueDistractors.has(distractor)) {
                  uniqueDistractors.add(distractor);
                  return true;
                }
                return false;
              });

              return {
                ...mcq,
                distractors: cleanedDistractors
              };
            });
            setGeneratedMCQs(cleanedGeneratedMCQs)
            console.log(generatedMCQs)
            setGenerateButton(false)
            setCurrentDataType(questionType)
            setIsLoading(false)
          })
          .catch((err) => {
            console.log(err)
            setIsLoading(false)
          })
      }
      if (questionType === 'Q&A Pair') {
        axios.post('http://127.0.0.1:8000/qanda/', {
          context: context,
          number: parseInt(count)
        })
          .then((res) => {
            console.log(res)
            setQueAndAnsPair(res.data)
            setGenerateButton(false)
            setCurrentDataType(questionType)
            setIsLoading(false)
          })
          .catch((err) => {
            console.log(err)
            setIsLoading(false)
          })
      }
    }
  }, [generateButton, context, generatedMCQs])

  //   const cleanedGeneratedMCQs = generatedMCQs.map(mcq => ({
  //     ...mcq,
  //     distractors: mcq.distractors.map(distractor => distractor.replace(/^[A-Z][).]/i, '').trim())
  // }));

  // // Now `cleanedGeneratedMCQs` contains the cleaned distractors
  // console.log(cleanedGeneratedMCQs);


  useEffect(() => {
    if (generatedMCQs.length === 0) {
      setIsMcqsGenerated(false)
    } else {
      setIsMcqsGenerated(true)
    }
  }, [generatedMCQs])

  useEffect(() => {
    if (queAndAnsPair.length === 0) {
      setIsQueAndAnsPairGenerated(false)
    } else {
      setIsQueAndAnsPairGenerated(true)
    }
  }, [queAndAnsPair])

  const handleSubmit = async () => {
    console.log('done')
    setGenerateButton(true)
    setIsMcqsGenerated(false)
    setIsQueAndAnsPairGenerated(false)
    setIsLoading(true)
  }

  const handleChange = (event) => {
    setCount(event.target.value);
  };

  const handleChangeType = (event) => {
    setQuestionType(event.target.value);
  };

  const numberOptions = Array.from({ length: 3 }, (_, index) => (
    <MenuItem key={index} value={index + 1}>
      {index + 1}
    </MenuItem>
  ));

  return (
    <div className="container" >
      <div className="left-section">
        <Typography
          sx={{
            textTransform: "none",
            mt: '10px',
            mb: '10px',
            textAlign: 'center',
            fontSize: { xs: 16, sm: 24 },
            fontWeight: 700,
            fontFamily: "cursive",
          }}
        >
          MCQs / Q&A Pair Generation
        </Typography>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <StyledTextarea
            aria-label="context"
            minRows={13}
            maxRows={13}
            placeholder="Please type or past your context here..."
            style={{ resize: 'vertical', fontSize: '20px', borderRadius: '5px 5px 0px 12px', fontFamily:'monospace' }}
            onChange={handleContext}
          />
        </div>
        <div style={{ display: "flex", justifyContent: "center", marginTop: '10px' }}>
          <Box sx={{ minWidth: 120, width: '40%', mr: '20px' }}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Question Count</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={count}
                label="Count"
                onChange={handleChange}
              >
                {numberOptions}
              </Select>
            </FormControl>
          </Box>

          <Box sx={{ minWidth: 120, width: '40%' }}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Question Type</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={questionType}
                label="Type"
                onChange={handleChangeType}
              >
                <MenuItem value={'MCQ'}>MCQ</MenuItem>
                <MenuItem value={'Q&A Pair'}>Q&A Pair</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </div>
        <div style={{ paddingTop: '10px', display: 'flex', justifyContent: 'center', paddingBottom: '30px' }}>
          <Button variant="contained"
            style={{ width: '85%', borderRadius: '5px 5px 0px 12px', textTransform: 'capitalize', fontSize: '20px' }}
            onClick={handleSubmit}>
            Generate
          </Button>
        </div>
      </div>
      <div className="right-section">
        {
          isLoading ? (
            <Loading />
          ) : currentDataType === 'Q&A Pair' ? (
            <QueAndAnsCard queAndAnsPair={queAndAnsPair}
              isQueAndAnsPairGenerated={isQueAndAnsPairGenerated}
              setQueAndAnsPair={setQueAndAnsPair} />
          ) : <MCQsCard generatedMCQs={generatedMCQs}
            isMcqsGenerated={isMcqsGenerated}
            setGeneratedMCQs={setGeneratedMCQs} />
        }
      </div>
    </div>
  )
}

export default MCQs
