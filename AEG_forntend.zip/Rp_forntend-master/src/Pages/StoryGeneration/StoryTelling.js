import React, { useState } from "react";
import {
  TextField,
  Button,
  Box,
  Paper,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  Typography,
  CircularProgress,
  Container,
} from "@mui/material";
import { styled } from "@mui/system";
import axios from "axios";
import VideoPlayer from "react-video-js-player";
// import "./global.css";
import video from "./story_video.mp4";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import CustomButton from "../../utils/CustomButton";
import Messagetext from "../../utils/Messagetext";
const theme = createTheme({
  spacing: 4,
});
const useStyles = styled((theme) => ({
  message: {
    marginTop: theme.spacing(2),
    padding: theme.spacing(2),
    border: `1px solid ${theme.palette.primary.main}`,
    borderRadius: theme.spacing(1),
  },
  gridContainer: {
    marginTop: theme.spacing(1),
  },
  gridItem: {
    padding: theme.spacing(2),
  },
  [theme.breakpoints.up("sm")]: {
    gridItem: {
      fontSize: "18px",
    },
  },

  formControl: {
    margin: theme.spacing(3),
    height: 130,
    width: "100%",
  },
}));

const StoryTelling = () => {
  const classes = useStyles();

  const [prompt, setPrompt] = useState("");
  const [genre, setGenre] = useState("general");
  const [story, setStory] = useState("");
  const [showTextFormat, setShowTextFormat] = useState(false);
  const [loading, setLoading] = useState(false);

  const [videoFile, setVideoFile] = useState();
  const [showVideoTag, setShowVideoTag] = useState(false);
  const [videoLoading, setVideoLoading] = useState(false);

  const generateStoryHandler = () => {
    setShowTextFormat(false);
    setLoading(true);
    setShowVideoTag(false);
    setVideoLoading(false);

    const formData = new FormData();
    formData.append("genre", genre);
    formData.append("prompt", prompt);

    axios
      .post("http://localhost:5000/story", formData)
      .then((response) => {
        if (response.data.story) {
          setStory(response.data.story);
          setShowTextFormat(true);
          setLoading(false);
        } else {
          alert(response.data.detail);
          setLoading(false);
          setShowTextFormat(false);
        }
      })
      .catch((error) => {
        console.error(error);
        alert(error);
        setShowTextFormat(false);
        setLoading(false);
      });
  };

  const createVideoHnadler = () => {
    setShowVideoTag(false);
    setVideoLoading(true);

    const formData = new FormData();
    formData.append("story", story);

    axios
      .post("http://localhost:5000/story/video", formData)
      .then((response) => {
        setVideoFile(response.data.video);
        setShowVideoTag(true);
        setVideoLoading(false);
      })
      .catch((error) => {
        console.error(error);
        setVideoLoading(false);
      });
  };

  const handleModelChange = (event) => {
    setGenre(event.target.value);
  };

  const handlePromptChanage = (event) => {
    setPrompt(event.target.value);
  };

  const handleReset = () => {
    setPrompt("");
    setGenre("general");
    setShowTextFormat(false);
    setLoading(false);
    setShowVideoTag(false);
    setVideoLoading(false);
  };

  return (
    <div>
      <div
        style={{
          padding: "20px",
          background: `#F9F6F2`,
        }}
      >
        <Box
          square
          minHeight={"82vh"}
          sx={{ display: "flex", flexDirection: "column" }}
        >
          <Container maxWidth="lg">
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <FormControl
                  variant="outlined"
                  style={{
                    margin: "0px",

                    // width: "100%",
                  }}
                >
                  <InputLabel id="model-label">Genere</InputLabel>
                  <Select
                    labelId="Topics-label"
                    value={genre}
                    onChange={handleModelChange}
                    label="Topic"
                  >
                    <MenuItem value="general">General</MenuItem>
                    {/* <MenuItem value='horror'>Horror</MenuItem>
                    <MenuItem value='myster'>Mystery</MenuItem> */}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  multiline
                  maxRows={3}
                  minRows={1}
                  className={classes.TextField}
                  fullWidth
                  variant="outlined"
                  label="Enter Prompt"
                  value={prompt}
                  onChange={handlePromptChanage}
                />
              </Grid>
              <Grid item xs={12}>
                <CustomButton
                  variant="contained"
                  color="primary"
                  onClick={generateStoryHandler}
                  style={{ marginRight: "10px" }}
                >
                  Generate Story
                </CustomButton>
                <CustomButton
                  variant="contained"
                  color="secondary"
                  onClick={handleReset}
                >
                  Reset
                </CustomButton>
              </Grid>
              {loading && (
                <Grid
                  item
                  xs={12}
                  style={{ display: "flex", justifyContent: "center" }}
                >
                  <CircularProgress size={80} />
                </Grid>
              )}
              {showTextFormat && (
                <Grid item xs={12}>
                  <TextField
                    multiline
                    maxRows={10}
                    minRows={3}
                    className={classes.TextField}
                    fullWidth
                    variant="outlined"
                    label="Generated Story"
                    value={story}
                  />
                  <br />
                  <br />
                  <CustomButton
                    variant="contained"
                    color="primary"
                    onClick={createVideoHnadler}
                    style={{ marginRight: "10px" }}
                  >
                    Create Video
                  </CustomButton>
                </Grid>
              )}

              {videoLoading && (
                <Grid
                  item
                  xs={12}
                  style={{ display: "flex", justifyContent: "center" }}
                >
                  <CircularProgress size={80} style={{ color: "#15616d" }} />
                </Grid>
              )}
              {showVideoTag && (
                <Grid item xs={12}>
                  <Messagetext variant="body">
                    Video Created at: Video Created
                    <br />
                    {/* {videoFile} */}
                  </Messagetext>
                  <Messagetext variant="body1">
                    <video controls width="1080" height="720">
                      <source src={video} type="video/mp4" />
                      Your browser does not support the video tag.
                    </video>
                  </Messagetext>
                </Grid>
              )}
            </Grid>
          </Container>
        </Box>
      </div>
    </div>
  );
};

export default StoryTelling;
