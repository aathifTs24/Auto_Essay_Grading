import React, { useEffect, useState } from "react";
import axios from "axios";
import { styled } from "@mui/system";
import {
  Box,
  Paper,
  Grid,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
  Button,
  Card,
  CardContent,
  List,
  CardActions,
  ListItem,
  ListItemText,
} from "@mui/material";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import CustomButton from "../../utils/CustomButton";
import Messagetext from "../../utils/Messagetext";
import Collapse from "@mui/material/Collapse";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
// const FeedbackText = styled(Typography)`
//   && {
//     font-size: 16px;
//     font-weight: 600; /* Example: Set font weight to bold */
//     color: #333; /* Example: Set text color to a specific color */
//     /* Add your custom styles here */
//   }
// `;

// const FeedbackPaper = styled(Paper)`
//   && {
//     padding: 16px;
//     background-color: #f0f0f0; /* Example: Set background color */
//     border: 1px solid #ccc; /* Example: Add a border */
//     /* Add your custom styles here */
//   }
// `;

const theme = createTheme({
  spacing: 4,
});

const useStyles = styled((theme) => ({
  gridItem: {
    fontSize: "18px",
  },
}));

const EssayGrading = () => {
  const [isFeedbackDetailsOpen, setIsFeedbackDetailsOpen] = useState(false);
  const [isFeedbackDetailsOpengrammer, setisFeedbackDetailsOpengrammer] =
    useState(false);
  const [
    isFeedbackDetailsOpenreferenceEssay,
    setisFeedbackDetailsOpenreferenceEssay,
  ] = useState(false);

  const handleFeedbackClick = () => {
    setIsFeedbackDetailsOpen(!isFeedbackDetailsOpen);
  };
  const handleFeedbackClickreferenceEssa = () => {
    setisFeedbackDetailsOpenreferenceEssay(
      !isFeedbackDetailsOpenreferenceEssay
    );
  };
  const handleFeedbackClickOpengrammer = () => {
    setisFeedbackDetailsOpengrammer(!isFeedbackDetailsOpengrammer);
  };
  const classes = useStyles();
  const [inputText, setInputText] = useState("");
  const [showTextFormat, setShowTextFormat] = useState(false);
  const [selectedModel, setSelectedModel] = useState("topic1");
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(false);

  const [generalFeedback, setGeneralFeedback] = useState("");
  const [scaledScore, setScaledScore] = useState(0);
  const [referenceEssay, setReferenceEssay] = useState("");
  const [grammarErrors, setGrammarErrors] = useState("");
  const [feedback, setFeedback] = useState([]);
  // const [genralarray, setgenralarray] = useState([]);
  const [topicStore, setTopicStore] = useState("");
  const [providefeedback1, setprovidefeedback1] = useState("");
  const [providefeedback2, setprovidefeedback2] = useState("");
  const [providefeedback3, setprovidefeedback3] = useState("");

  const handleGenerateEssay = () => {
    setShowTextFormat(false);
    setLoading(true);

    const data = {
      topic: selectedModel,
      essay: inputText.trim(),
    };

    axios
      .post("http://localhost:5000/essay", data)
      .then((response) => {
        setShowTextFormat(true);
        setScore(response.data.score);
        const feedbackData = response.data.feedback
          .split("\n")
          .map((item) => item.trim().replace(/^-/, ""));
        const feedbackObject = {};
        feedbackData.forEach((item, index) => {
          feedbackObject[index] = item;
        });

        setFeedback(feedbackObject);

        // const feedbackKeys = [
        //   "wordCount",
        //   "totalSentences",
        //   "similarity",
        //   "adjectiveCount",
        //   "questionsCount",
        //   "quotationsCount",
        //   "exclamationCount",
        //   "commasCount",
        //   "namedEntitiesCount",
        //   "locationsCount",
        //   "personNamesCount",
        //   "organizationNamesCount",
        // ];
        // const newFeedback = {};
        // for (let i = 1; i < feedbackData.length; i++) {
        //   const [key, value] = feedbackData[i]
        //     .split(":")
        //     .map((item) => item.trim());
        //   newFeedback[feedbackKeys[i - 1]] = value;
        // }
        console.log(response.data);
        console.log(response.data.grammar);

        setGeneralFeedback(response.data.general_feedback);
        setScaledScore(response.data.scaled_score);
        setReferenceEssay(response.data.referenc_essay);
        setGrammarErrors(response.data.grammer);
        setprovidefeedback1(response.data.general_feedback_1);
        setprovidefeedback2(response.data.general_feedback_2);
        setprovidefeedback3(response.data.general_feedback_3);
        setLoading(false);
        console.log(feedback);
        console.log(generalFeedback);
        // const generalFeedbackArray = generalFeedback.split("\n");
        // setgenralarray(generalFeedbackArray);
        // console.log(generalFeedbackArray);
      })
      .catch((error) => {
        toast.error("An error occurred during processing. Please try again.");
        console.error(error);
        setLoading(false);
      });
  };

  const handleModelChange = (event) => {
    setSelectedModel(event.target.value);
  };

  useEffect(() => {
    if (selectedModel) {
      if (selectedModel === "topic1") {
        setTopicStore(12);
      }
      if (selectedModel === "topic2") {
        setTopicStore(6);
      }
      if (selectedModel === "topic3") {
        setTopicStore(3);
      }
      if (selectedModel === "topic4") {
        setTopicStore(3);
      }
      if (selectedModel === "topic5") {
        setTopicStore(4);
      }
      if (selectedModel === "topic6") {
        setTopicStore(4);
      }
      if (selectedModel === "topic7") {
        setTopicStore(30);
      }
      if (selectedModel === "topic8") {
        setTopicStore(60);
      }
    }
  }, [selectedModel]);

  const handleReset = () => {
    setInputText("");
    setSelectedModel("");
    setShowTextFormat(false);
    setLoading(false);
  };

  return (
    <>
      <ToastContainer />
      <div
        style={{
          padding: "20px",
          marginTop: "10px",
          marginBottom: "50px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          background: `#F9F6F2`,
          backgroundSize: "cover",
        }}
      >
        <Box sx={{ minHeight: "100vh", padding: theme.spacing(2) }}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Typography variant="h5">
                Let's select a Question set to start Writing....
              </Typography>
            </Grid>

            <Grid container justifyContent="center" item xs={12}>
              <TableContainer
                component={Paper}
                sx={{ margin: "1.5px auto" }}
                style={{ border: "35px solid white" }}
              >
                <Table
                  sx={{ minWidth: 500 }}
                  size="small"
                  aria-label="a dense table"
                >
                  <TableHead>
                    <TableRow>
                      <TableCell
                        align="right"
                        style={{
                          border: "1px solid #e0e0e0",
                          fontWeight: 600, // Use fontWeight to make the font bold
                        }}
                      >
                        #
                      </TableCell>

                      <TableCell
                        align="left"
                        style={{
                          border: "1px solid #e0e0e0",
                          fontWeight: 600, // Use fontWeight to make the font bold
                        }}
                      >
                        Questions
                      </TableCell>

                      <TableCell
                        align="right"
                        style={{
                          border: "1px solid #e0e0e0",
                          fontWeight: 600, // Use fontWeight to make the font bold
                        }}
                      >
                        MinScore
                      </TableCell>

                      <TableCell
                        align="right"
                        style={{
                          border: "1px solid #e0e0e0",
                          fontWeight: 600, // Use fontWeight to make the font bold
                        }}
                      >
                        MaxScore
                      </TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {rows.map((row) => (
                      <TableRow
                        key={row.name}
                        sx={{
                          "& td, & th": {
                            border: "1px solid #e0e0e0",
                            textAlign: "left",
                          }, // Add borders for cells
                        }}
                      >
                        <TableCell align="left">{row.name}</TableCell>
                        <TableCell align="left">{row.No}</TableCell>
                        <TableCell align="center">{row.Questions}</TableCell>
                        <TableCell align="right">{row.MinScore}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <FormControl
                variant="outlined"
                sx={{ minWidth: 120, width: "100%" }}
              >
                <InputLabel id="model-label">Topics</InputLabel>
                <Select
                  labelId="Topics-label"
                  value={selectedModel}
                  onChange={handleModelChange}
                  label="Topic"
                >
                  {topicOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                multiline
                maxRows={30}
                minRows={7}
                fullWidth
                variant="outlined"
                label="Enter Text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <CustomButton
                variant="contained"
                color="primary"
                onClick={handleGenerateEssay}
                style={{ marginRight: "10px" }}
              >
                Grade Essay
              </CustomButton>
              <CustomButton
                variant="contained"
                color="secondary"
                onClick={handleReset}
              >
                Reset
              </CustomButton>
            </Grid>
            {loading && (
              <Grid
                item
                xs={12}
                style={{ display: "flex", justifyContent: "center" }}
              >
                <CircularProgress size={80} style={{ color: "#15616d" }} />
              </Grid>
            )}
            {showTextFormat && (
              <Grid item xs={12}>
                <Messagetext variant="h6" className={classes.message}>
                  <h1>
                    {" "}
                    Your Current Grade : {score} {" ("}
                    {scaledScore}
                    {" )"}
                  </h1>
                  Maximum possible score on this question is {topicStore}
                  <br />
                </Messagetext>
                <br />
                <Messagetext>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Typography> EVALUATION: </Typography>
                      <Paper
                        className={classes.paper}
                        style={{ padding: "10px" }}
                      >
                        <Typography>{providefeedback1}</Typography>
                      </Paper>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography> VOCABULART DIVERSITY RESULTS: </Typography>
                      <Paper style={{ padding: "10px" }}>
                        <Typography variant="body1">
                          {providefeedback2}
                        </Typography>
                      </Paper>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography> GRAMMER RESULTS: </Typography>
                      <Paper style={{ padding: "10px" }}>
                        <Typography variant="body1">
                          {providefeedback3}
                        </Typography>
                      </Paper>
                    </Grid>
                  </Grid>

                  <CustomButton
                    variant="contained"
                    color="primary"
                    onClick={handleFeedbackClickOpengrammer}
                    startIcon={<ExpandMoreIcon />}
                  >
                    View corrected
                  </CustomButton>
                </Messagetext>

                <br />

                <Collapse in={isFeedbackDetailsOpengrammer}>
                  {" "}
                  <Messagetext variant="h6">{grammarErrors}</Messagetext>
                </Collapse>
                <CustomButton
                  variant="contained" // Change to 'outlined' if you want an outlined button
                  color="primary" // Change the color to your desired color
                  onClick={handleFeedbackClick}
                  startIcon={<ExpandMoreIcon />}
                  style={{ display: "flex", justifyContent: "right" }}
                >
                  Additional Feedbacks
                </CustomButton>
                <br />
                <Collapse in={isFeedbackDetailsOpen}>
                  <Messagetext variant="h6">
                    {feedback[0]}
                    <ul>
                      {Object.keys(feedback)
                        .slice(1, 13)
                        .map((key) => (
                          <li key={key}>{feedback[key]}</li>
                        ))}
                    </ul>
                  </Messagetext>
                </Collapse>
                <CustomButton
                  variant="contained" // Change to 'outlined' if you want an outlined button
                  color="primary" // Change the color to your desired color
                  onClick={handleFeedbackClickreferenceEssa}
                  startIcon={<ExpandMoreIcon />}
                  style={{ display: "flex", justifyContent: "right" }}
                >
                  Highest Graded Essay
                </CustomButton>
                <Collapse in={isFeedbackDetailsOpenreferenceEssay}>
                  <Messagetext variant="h6">{referenceEssay}</Messagetext>
                </Collapse>
              </Grid>
            )}
            {/* <Grid container justify="center">
              {showTextFormat && (
                <Grid item xs={12}>
                  <Card>
                    <CardContent>
                      <Typography variant="h6">
                        <h1>
                          Your Current Grade: {score} ({scaledScore})
                        </h1>
                        Maximum possible score on this question is {topicStore}
                      </Typography>
                      <List>
                        {genralarray.map((line, index) => (
                          <ListItem key={index}>
                            <ListItemText primary={line} />
                          </ListItem>
                        ))}
                      </List>
                    </CardContent>
                    <CardActions>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={handleFeedbackClickOpengrammer}
                        startIcon={<ExpandMoreIcon />}
                      >
                        View corrected
                      </Button>
                    </CardActions>
                    <Collapse in={isFeedbackDetailsOpengrammer}>
                      <CardContent>
                        <Typography variant="h6">{grammarErrors}</Typography>
                      </CardContent>
                    </Collapse>
                    <CardActions>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={handleFeedbackClick}
                        startIcon={<ExpandMoreIcon />}
                        style={{ marginLeft: "auto" }}
                      >
                        Additional Feedbacks
                      </Button>
                    </CardActions>
                    <Collapse in={isFeedbackDetailsOpen}>
                      <CardContent>
                        <Typography variant="h6">{feedback[0]}</Typography>
                        <List>
                          {Object.keys(feedback)
                            .slice(1, 13)
                            .map((key) => (
                              <ListItem key={key}>
                                <ListItemText primary={feedback[key]} />
                              </ListItem>
                            ))}
                        </List>
                      </CardContent>
                    </Collapse>
                    <CardActions>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={handleFeedbackClickreferenceEssa}
                        startIcon={<ExpandMoreIcon />}
                        style={{ marginLeft: "auto" }}
                      >
                        Highest Graded Essay
                      </Button>
                    </CardActions>
                    <Collapse in={isFeedbackDetailsOpenreferenceEssay}>
                      <CardContent>
                        <Typography variant="h6">{referenceEssay}</Typography>
                      </CardContent>
                    </Collapse>
                  </Card>
                </Grid>
              )}
            </Grid> */}
          </Grid>
        </Box>
      </div>
    </>
  );
};

export default EssayGrading;
function createData(name, No, Questions, MinScore, MaxScore) {
  return { name, No, Questions, MinScore, MaxScore };
}
const rows = [
  createData(
    1,
    "Write a letter to your local newspaper in which you state your opinion on the effects computers have on people. Persuade the readers to agree with you",
    2,
    12
  ),
  createData(
    2,
    "Compose a persuasive newspaper essay discussing your stance on censorship in libraries. Argue whether offensive materials should be removed from shelves.",
    1,
    6
  ),
  createData(
    3,
    "Write a response that explains how the features of the setting affect the cyclist. In your response, include examples from the essay that support your conclusion.",
    0,
    3
  ),
  createData(
    4,
    "When they come back, Saeng vowed silently to herself, in the spring, when the snows melt and the geese return and this hibiscus is budding, then I will take that test again Write a response that explains why the author concludes the story with this paragraph.",
    0,
    3
  ),
  createData(
    5,
    "Describe the mood created by the author in the memoir. Support your answer with relevant and specific information from the memoir.",
    0,
    4
  ),
  createData(
    6,
    "Based on the excerpt, describe the obstacles the builders of the Empire State Building faced in attempting to allow dirigibles to dock there.",
    0,
    4
  ),
  createData(
    7,
    "Write a story about a time when you were patient OR write a story about a time when someone you know was patient OR write a story in your own way about patience.",
    0,
    30
  ),
  createData(
    8,
    "We all understand the benefits of laughter. Many other people believe that laughter is an important part of any relationship. Tell a true story in which laughter was one element or part.",
    0,
    60
  ),
];

const topicOptions = [
  {
    label:
      "Topic 1 - Write a letter to your local newspaper in which you state your opinion on the effects computers have on people. Persuade the readers to agree with you",
    value: "topic1",
  },
  {
    label:
      "Topic 2 - Compose a persuasive newspaper essay discussing your stance on censorship in libraries. Argue whether offensive materials should be removed from shelves.",
    value: "topic2",
  },
  {
    label:
      "Topic 3 - Write a response that explains how the features of the setting affect the cyclist. In your response, include examples from the essay that support your conclusion.",
    value: "topic3",
  },
  {
    label:
      "Topic 4 - When they come back, Saeng vowed silently to herself, in the spring, when the snows melt and the geese return and this hibiscus is budding, then I will take that...",
    value: "topic4",
  },
  {
    label:
      "Topic 5 - Describe the mood created by the author in the memoir. Support your answer with relevant and specific information from the memoir.	",
    value: "topic5",
  },
  {
    label:
      "Topic 6 - Based on the excerpt, describe the obstacles the builders of the Empire State Building faced in attempting to allow dirigibles to dock there.	",
    value: "topic6",
  },
  {
    label:
      "Topic 7 - Write a story about a time when you were patient OR write a story about a time when someone you know was patient OR write a story in your own way about patience.	",
    value: "topic7",
  },
  {
    label:
      "Topic 8 - We all understand the benefits of laughter. Many other people believe that laughter is an important part of any relationship. Tell a true story in which laughter was one element or part.",
    value: "topic8",
  },
  // Add more options for additional models
];
