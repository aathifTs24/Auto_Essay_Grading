import React from "react";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import CardContent from "@mui/material/CardContent";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/system";
import shortNotes from "../Assets/Taking notes-amico.png";
import mcqs from "../Assets/mcq.png";
import Storytelling from "../Assets/Storytelling.png";
import essay_grading from "../Assets/essay_grading.png";

const StyledCard = styled(Card)(({ theme }) => ({
  minWidth: 200,
  margin: theme.spacing(2),
  backgroundColor: "#f0f0f0",
  boxShadow: "2px 2px 6px rgba(0, 0, 0, 0.2)",
  transition: "transform 0.2s",
  "&:hover": {
    transform: "scale(1.05)",
  },
}));

function Dashboard() {
  const cards = [
    {
      title: "MCQs generation",
      imageUrl: mcqs,
      navigationUrl: "/mcqs",
    },
    {
      title: "Essay grading",
      imageUrl: essay_grading,
      navigationUrl: "/essay-grading",
    },
    {
      title: "Short Notes generation",
      imageUrl: shortNotes,
      navigationUrl: "/short-notes",
    },

    {
      title: "Story generation",
      imageUrl: Storytelling,
      navigationUrl: "/story-generation",
    },
  ];

  return (
    <Box
      component={Paper}
      elevation={1}
      square
      minHeight={"82vh"}
      sx={{
        display: "flex",
        flexDirection: "column",
        background: `#F9F6F2`,
      }}
    >
      <Grid container spacing={4} p={5}>
        {cards.map((card, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <StyledCard>
              <CardContent>
                <Typography variant="h6" align="center">
                  {card.title}
                </Typography>
                <a href={card.navigationUrl}>
                  <img
                    src={card.imageUrl}
                    alt={card.title}
                    style={{
                      width: "100%",
                      marginTop: "10px",
                      marginRight: "20px",
                      alignContent: "center",
                    }}
                  />
                </a>
              </CardContent>
            </StyledCard>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default Dashboard;
