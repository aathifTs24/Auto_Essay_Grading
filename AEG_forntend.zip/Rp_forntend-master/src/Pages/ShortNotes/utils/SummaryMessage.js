import React from "react";
import { styled } from "@mui/system";

const SummaryMessage = styled("div")(({ theme }) => ({
  marginTop: theme.spacing(1),
  padding: theme.spacing(2),
  border: `2px solid #15616d`,
  borderRadius: theme.spacing(1.5),
}));

export default SummaryMessage;
