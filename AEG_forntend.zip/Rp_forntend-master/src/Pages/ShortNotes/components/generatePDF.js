import { jsPDF } from "jspdf";

const generatePDF = (
  shortNotes,
  { setAlertMessage, setSeverity, setOpenSnackbar }
) => {
  const doc = new jsPDF();
  doc.setFontSize(16);
  const headingText = "Generated Short Notes";
  const headingWidth =
    (doc.getStringUnitWidth(headingText) * doc.internal.getFontSize()) /
    doc.internal.scaleFactor;
  const xCoordinate = (doc.internal.pageSize.getWidth() - headingWidth) / 2;
  doc.text(headingText, xCoordinate, 20);

  doc.setLineWidth(0.5);
  doc.line(20, 25, doc.internal.pageSize.getWidth() - 20, 25);

  const notes = shortNotes
    .split(". ")
    .map((s) => s.trim())
    .filter(Boolean); // refined splitting
  let totalWordCount = 0;

  let yPos = 35;

  notes.forEach((note) => {
    doc.setFontSize(10);
    const bulletPoint = "\u2022";
    const formattedNote = `${bulletPoint} ${note}`;

    const wordCount = note.split(/\s+/).filter(Boolean).length;
    totalWordCount += wordCount;

    // Handling long sentences
    const lines = doc.splitTextToSize(
      formattedNote,
      doc.internal.pageSize.getWidth() - 20
    );

    lines.forEach((line) => {
      // Check page overflow
      if (yPos > doc.internal.pageSize.getHeight() - 20) {
        doc.addPage();
        yPos = 10;
      }

      doc.text(line, 10, yPos);
      yPos += 10;
    });
  });

  if (yPos > doc.internal.pageSize.getHeight() - 20) {
    doc.addPage();
    yPos = 10;
  }

  doc.setFontSize(12);
  doc.text("Total Word Count: " + totalWordCount, 10, yPos);

  const document = doc.save("ShortNotes.pdf");
  if (document) {
    setAlertMessage("PDF has been downloaded");
    setSeverity("success");
    setOpenSnackbar(true);
  } else {
    setAlertMessage("Error! couldn't download");
    setSeverity("error");
    setOpenSnackbar(true);
  }
};

export default generatePDF;
