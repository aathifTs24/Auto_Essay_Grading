import React, { useRef, useState } from "react";
import axios from "axios";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import { styled } from "@mui/system";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import TranslateIcon from "@mui/icons-material/Translate";
import { Box, Paper } from "@mui/material";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { CSSTransition } from "react-transition-group";
import BeatLoader from "react-spinners/BeatLoader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material";
import imageset from "../../genrateImage/wordcloud.png";
import generatePDF from "./components/generatePDF";
import upload from "../../Assets/Video upload-pana (1).png";
import summary from "../../Assets/Taking notes-amico.png";
import back_animation from "../../Assets/uploading_image.png";
import LibraryMusicIcon from "@mui/icons-material/LibraryMusic";
import VolumeUpIcon from "@mui/icons-material/VolumeUp";
import DownloadIcon from "@mui/icons-material/Download";
import CustomButton from "../../utils/CustomButton";
import SummaryMessage from "./utils/SummaryMessage";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import "./animations.css";
import StopIcon from "@mui/icons-material/Stop";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import PictureAsPdfTwoToneIcon from "@mui/icons-material/PictureAsPdfTwoTone";

const theme = createTheme({
  spacing: 4,
});
const StyledCardMedia = styled(CardMedia)({
  height: "130px",
  width: "100%",
  objectFit: "contain",
  transition: "transform 0.2s",
  "&:hover": {
    color: "black",
    transform: "scale(1.05)",
  },
});

const StyledDropzone = styled("div")({
  border: "2px dashed #cccccc",
  borderRadius: "4px",
  padding: theme.spacing(5),
  textAlign: "center",
  cursor: "pointer",
  backgroundColor: "white",
  background: "linear-gradient(to right, #EDEDED, #F7F7F7)",
  boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.1)",
  transition: "all 0.3s ease",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  "&:hover": {
    backgroundColor: "#f5f5f5",
    boxShadow: "0px 6px 16px rgba(0, 0, 0, 0.1)",
  },
});

const StyledSummaryInput = styled("input")({
  padding: theme.spacing(3),
  fontSize: "14px",
  border: `1px solid black`,
  borderRadius: theme.spacing(0.5),
  transition: "border 0.3s ease",
  "&:focus": {
    borderColor: "2px solid #15616d",
  },
});

function ShortNotes() {
  const [file, setFile] = useState(null);
  const [open, setOpen] = React.useState(false);
  const [fileName, setFileName] = useState("");
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [transilationloading, settransilationloading] = useState(false);
  const [copySuccess, setCopySuccess] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [summaryWordCount, setSummaryWordCount] = useState(0);
  const fileInputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);
  const [summaryLength, setSummaryLength] = useState(100);
  const [imageUrl, setImageUrl] = useState(null);
  const [translatedSummary, setTranslatedSummary] = useState(null);
  const [selectedLanguage, setSelectedLanguage] = useState("ta");
  const [messagedcountdetails, setmessagedcountdetails] = useState("");
  const [wordcount, setWordCount] = useState("loading...");

  // Snackbar handlers
  const handleClick = () => {
    setOpen(true);
  };

  const onFileChange = async (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile.type !== "application/pdf") {
      toast.error("Invalid file type. Please select a PDF file.");
      return;
    }

    setFile(selectedFile);
    setFileName(selectedFile.name);
    setMessage(null);

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      // Sending the file to the backend
      const response = await axios.post(
        `http://localhost:5000/short_note/word_count_range`,
        formData
      );

      // Extracting relevant information from the response
      const { minCount, maxCount, filename, word_count } = response.data;

      // Update the state with the word count obtained from the backend
      setWordCount(word_count);
      setmessagedcountdetails(
        `You can select a summary between ${minCount} to ${maxCount} words.`
      );

      // If you have any other states or logic dependent on minCount, maxCount, filename, or word_count, add them here
    } catch (error) {
      // Handling errors
      toast.error(
        "An error occurred during file processing. Please try again."
      );
    }
  };

  const onFileUpload = () => {
    handleClick();

    const requestData = {
      filename: fileName,
      summaryLength: summaryLength,
    };

    setLoading(true);

    axios
      .post("http://localhost:5000/short_note/summarize1", requestData)
      .then((response) => {
        setMessage(response.data);

        setImageUrl(response.data.wordcloud_image);

        console.log(response.data.summary);
        setLoading(false);
        const summaryWords = response.data.summary
          .split(/\s+/)
          .filter((word) => word !== "");
        setSummaryWordCount(summaryWords.length);
      })
      .catch((error) => {
        setLoading(false);
        if (error.response && error.response.status === 400) {
          toast.error(error.response.data.detail);
        } else {
          console.log("hello");
          console.log(error);

          toast.error("An error occurred during processing. Please try again.");
        }
      });
  };

  const onCopy = () => {
    setCopySuccess("Copied!");
  };

  const onReset = () => {
    settransilationloading(false);
    setMessage("");
    setLoading(false);
    setFile(null);
    setFileName(null);
    setMessage(null);
    setTranslatedSummary(null);
    setCopySuccess("");
  };

  const speak = (text) => {
    let speech = new SpeechSynthesisUtterance();
    speech.text = text;
    window.speechSynthesis.speak(speech);
    setSpeaking(true);
    speech.onend = function () {
      setSpeaking(false);
    };
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
  };

  // drag and drop

  const onDragOver = (event) => {
    event.preventDefault();
    setDragActive(true);
  };

  const onDragLeave = () => {
    setDragActive(false);
  };

  const onDrop = (event) => {
    event.preventDefault();
    if (event.dataTransfer.items) {
      if (event.dataTransfer.items[0].kind === "file") {
        const file = event.dataTransfer.items[0].getAsFile();

        onFileChange({ target: { files: [file] } });
      }
    }
    setDragActive(false);
  };
  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([message.summary], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = "summary.txt";
    document.body.appendChild(element);
    element.click();
  };
  const handleTranslatedDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([translatedSummary], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = "translated summary.txt";
    document.body.appendChild(element);
    element.click();
  };

  const handleTranslatedDownloadAsPDF = () => {
    const doc = new jsPDF();
    const bulletPoints = translatedSummary.split("\n");
    let verticalOffset = 10; // Starting vertical position
    const horizontalOffset = 10; // Starting horizontal position
    const lineSpacing = 7; // Vertical space between each line

    // Add each bullet point to the PDF
    for (const point of bulletPoints) {
      doc.text(point, horizontalOffset, verticalOffset);
      verticalOffset += lineSpacing;
    }

    // Create a Blob from the PDF
    const pdfBlob = new Blob([doc.output()], { type: "application/pdf" });
    const element = document.createElement("a");
    element.href = URL.createObjectURL(pdfBlob);
    element.download = "translated summary.pdf";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleTranslation = async (language) => {
    settransilationloading(true);
    // Ensure language is one of the supported languages
    if (!["si", "ta"].includes(language)) {
      console.error("Unsupported language");
      return;
    }
    const requestData = {
      text: message.summary,
      language: language,
    };
    axios
      .post("http://localhost:5000/short_note/translate/", requestData) // fast api
      .then((response) => {
        settransilationloading(false);
        setTranslatedSummary(response.data.translatedText);
        // settransitionloading(false);
      })
      .catch((error) => {
        settransilationloading(false);
        toast.error("Failed to translate text. Please try again.");
      });
  };

  const handleSummaryAudio = async (summary) => {
    console.log("hello");
    console.log(summary);

    const requestData = {
      text: summary,
    };
    toast.success("summary Audio getting Download please wait");

    try {
      const response = await axios.post(
        "http://localhost:5000/short_note/generate_audio",
        requestData,
        { responseType: "arraybuffer" }
      );

      const audioData = response.data;
      console.log("hello2");

      // Create a Blob from the audio data and create a download link
      const blob = new Blob([audioData], { type: "audio/mpeg" });
      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = "summaryaudio.mp3"; // Set the desired file name

      // Append the link to the document and trigger a click event
      document.body.appendChild(a);
      a.click();

      // Clean up by removing the link and revoking the Blob
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      // Display a toast message on successful download
      toast.success("Audio generated and downloaded successfully.");
    } catch (error) {
      toast.error("Failed to generate audio. Please try again.");
    }
  };

  const handleChange = (event) => {
    setSelectedLanguage(event.target.value);
  };

  const handleTranslate = () => {
    handleTranslation(selectedLanguage);
  };
  const handleGeneratePDF = () => {
    if (message && !loading) {
      // Check if there is a message and it's not in the loading state
      const textToGeneratePDF = message.summary; // You can adjust this based on what text you want in the PDF

      generatePDF(textToGeneratePDF, {
        setAlertMessage: (message) => {
          toast.success(message); // Display a success message
        },
        setSeverity: (severity) => {
          // You can handle the severity here if needed
        },
        setOpenSnackbar: (open) => {
          // You can handle the Snackbar open state here if needed
        },
      });
    } else {
      // Handle the case where there is no message or it's still loading
      toast.error(
        "Cannot generate PDF at the moment. Please wait for the shortNotes."
      );
    }
  };

  return (
    <>
      <ToastContainer />

      <Box
        component={Paper}
        elevation={1}
        square
        minHeight={"82vh"}
        sx={{
          display: "flex",
          flexDirection: "column",
          background: `#F9F6F2`,
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center center",
        }}
      >
        <Container
          maxWidth="lg"
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            marginTop: theme.spacing(2),
            padding: theme.spacing(4),
          }}
        >
          <Grid container spacing={3} mt={2}>
            <Grid item xs={12} sm={6} sx={{ p: 2 }}>
              <StyledCardMedia component="img" image={upload} title="Upload" />
              <CardContent>File upload to document </CardContent>{" "}
              <StyledDropzone
                style={{
                  ...(dragActive
                    ? {
                        borderColor: "#2196F3",
                        backgroundColor: "#E3F2FD",
                        boxShadow: "0px 6px 16px rgba(33, 150, 243, 0.2)",
                      }
                    : {}),
                }}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
                onClick={() => fileInputRef.current.click()}
              >
                <div
                  style={{
                    marginBottom: theme.spacing(3),
                    fontSize: "6rem",
                    color: "#2196F3",
                  }}
                >
                  📄
                </div>
                <Typography
                  variant="body2"
                  style={{ marginTop: theme.spacing(2), color: "#666" }}
                  gutterBottom
                >
                  PDF only
                </Typography>
                <label htmlFor="file-upload">
                  <CustomButton
                    component="span"
                    variant="contained"
                    color="primary"
                    disabled={loading}
                  >
                    Select File
                  </CustomButton>
                </label>
                {/* Additional Text */}
                <Typography
                  variant="body2"
                  style={{ marginTop: theme.spacing(2), color: "#666" }}
                >
                  or Drag & Drop
                </Typography>
                <input
                  type="file"
                  accept=".pdf"
                  onChange={onFileChange}
                  id="file-upload"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                />
              </StyledDropzone>
              {file && (
                <>
                  <SummaryMessage variant="subtitle1">
                    File Selected: {fileName}
                  </SummaryMessage>
                  {wordcount && (
                    <SummaryMessage variant="subtitle1">
                      word count : {wordcount}
                    </SummaryMessage>
                  )}
                </>
              )}
              <br />
              <div> {file && <div>{messagedcountdetails}</div>}</div>
              <br />
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  width: "550px",
                  margin: `${theme.spacing(2)}px 0`,
                  fontFamily: "Arial, sans-serif",
                }}
              >
                <label
                  style={{
                    marginBottom: theme.spacing(1),
                    fontWeight: "bold",
                    fontSize: "16px",
                  }}
                >
                  Desired Summary Length
                </label>
                <StyledSummaryInput
                  type="number"
                  value={summaryLength}
                  onChange={(e) => setSummaryLength(e.target.value)}
                  placeholder="Enter number of words"
                />
              </div>
              <CustomButton
                variant="contained"
                color="primary"
                onClick={onFileUpload}
                disabled={!file || loading}
                startIcon={loading && <BeatLoader color="#15616d" />}
              >
                Shortnotes Generation
              </CustomButton>
              <CustomButton
                variant="contained"
                color="secondary"
                onClick={onReset}
                disabled={!file}
              >
                Reset
              </CustomButton>
              <br />
              <br />
              <div
                style={{
                  // backgroundColor: "rgba(255, 255, 255, 0.5",
                  width: "400px",
                  height: "400px",
                }}
              >
                <img
                  src={back_animation}
                  alt="Image Description"
                  style={{ width: "100%", height: "100%" }}
                />
              </div>
              <br />
              <br />
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              // style={{ fontSize: breakpoints.up("sm") ? "18px" : "inherit" }}
            >
              <StyledCardMedia
                component="img"
                image={summary} // Replace with your image URL
                title="Summary"
              />
              <CardContent>Short notes </CardContent>
              {!message && (
                <SummaryMessage variant="body1">
                  {loading && <BeatLoader color="#15616d" />}
                </SummaryMessage>
              )}
              {message && (
                <CSSTransition
                  in={!!message}
                  timeout={300}
                  classNames="fade"
                  unmountOnExit
                >
                  <>
                    <SummaryMessage variant="body1">
                      <ul> {loading && <BeatLoader color="#15616d" />}</ul>
                      {!loading && (
                        <>
                          <div>
                            <img
                              src={imageset}
                              alt="Generated WordCloud"
                              style={{ width: "100%", height: "300px" }}
                            />

                            {/* )} */}
                          </div>{" "}
                          <ul>
                            {message.summary.split(".").map((point, index) => (
                              <li key={index}>{point.trim()}</li>
                            ))}
                          </ul>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                            }}
                          >
                            {/* Typography on the left */}
                            <Typography
                              variant="body1"
                              style={{ fontWeight: "bold", color: "#15616d" }}
                            >
                              {summaryWordCount} words
                            </Typography>

                            {/* Icon buttons grouped together on the right */}
                            <div style={{ display: "flex", gap: "16px" }}>
                              {" "}
                              {/* gap provides space between the buttons */}
                              <CopyToClipboard
                                text={message.summary}
                                onCopy={onCopy}
                              >
                                <span>
                                  <CustomButton color="primary">
                                    <FileCopyIcon />
                                  </CustomButton>
                                  {/* <span>Copy</span> */}
                                </span>
                              </CopyToClipboard>
                              <span>
                                <CustomButton
                                  color="primary"
                                  onClick={handleDownload}
                                >
                                  {" "}
                                  <DownloadIcon />
                                </CustomButton>
                                {/* <span>Download</span> */}
                              </span>
                              <span>
                                {" "}
                                <CustomButton
                                  variant="outlined"
                                  color="primary"
                                  onClick={handleGeneratePDF}
                                  disabled={!message || loading}
                                >
                                  <PictureAsPdfTwoToneIcon />
                                </CustomButton>
                              </span>
                            </div>
                          </div>
                        </>
                      )}
                    </SummaryMessage>
                    <div
                      style={{
                        display: "flex",
                        // justifyContent: "space-around",
                        alignItems: "center",
                      }}
                    >
                      <CustomButton
                        variant="contained"
                        color="primary"
                        onClick={() => speak(message.summary)}
                        disabled={speaking}
                        startIcon={
                          speaking ? (
                            <BeatLoader color="#15616d" />
                          ) : (
                            <VolumeUpIcon />
                          )
                        }
                      >
                        Speak
                      </CustomButton>
                      <CustomButton
                        variant="contained"
                        color="primary"
                        onClick={stopSpeaking}
                        startIcon={<StopIcon />}
                      >
                        Stop
                      </CustomButton>
                      <CustomButton
                        variant="contained"
                        color="primary"
                        startIcon={<LibraryMusicIcon />}
                        onClick={() => handleSummaryAudio(message.summary)}
                        disabled={speaking}
                      >
                        Download Audio
                      </CustomButton>
                    </div>
                    {/* <Button
                      variant="contained"
                      color="primary"
                      onClick={onFileUpload}
                      className={classes.button}
                      disabled={!file || loading}
                      startIcon={<RefreshIcon />}
                    >
                      Re-generate
                    </Button> */}

                    <br />
                    <br />
                    {/* Translate */}
                    <Typography variant="body1">
                      Translated ShortNotes
                    </Typography>
                    <br />

                    <div style={{ display: "flex", alignItems: "center" }}>
                      <FormControl
                        variant="outlined"
                        style={{ minWidth: "150px", marginRight: "20px" }}
                      >
                        <InputLabel id="language-select-label">
                          Language
                        </InputLabel>
                        <Select
                          labelId="language-select-label"
                          value={selectedLanguage}
                          onChange={handleChange}
                          label="Language"
                        >
                          <MenuItem value="ta">Tamil</MenuItem>
                          <MenuItem value="si">Sinhala</MenuItem>
                        </Select>
                      </FormControl>

                      <CustomButton
                        variant="contained"
                        color="primary"
                        endIcon={<TranslateIcon />}
                        disabled={!file || transilationloading}
                        startIcon={
                          transilationloading && <BeatLoader color="#15616d" />
                        }
                        onClick={handleTranslate}
                      >
                        Translate
                      </CustomButton>
                    </div>
                    <br />
                    {translatedSummary && !loading && (
                      <>
                        <SummaryMessage variant="body1">
                          <ul>
                            {translatedSummary
                              .split(".")
                              .map((point, index) => (
                                <li key={index}>{point.trim()}</li>
                              ))}
                          </ul>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                            }}
                          >
                            {/* Typography on the left */}
                            <Typography
                              variant="body1"
                              style={{ fontWeight: "bold", color: "#15616d" }}
                            >
                              {summaryWordCount} words
                            </Typography>

                            {/* Icon buttons grouped together on the right */}
                            <div style={{ display: "flex", gap: "16px" }}>
                              {" "}
                              {/* gap provides space between the buttons */}
                              <CopyToClipboard
                                text={translatedSummary}
                                onCopy={onCopy}
                              >
                                <span>
                                  <CustomButton color="primary">
                                    <FileCopyIcon />
                                  </CustomButton>
                                </span>
                              </CopyToClipboard>
                              <span>
                                <CustomButton
                                  color="primary"
                                  onClick={handleTranslatedDownload}
                                >
                                  <DownloadIcon />
                                </CustomButton>
                              </span>
                            </div>
                          </div>
                        </SummaryMessage>
                      </>
                    )}

                    {copySuccess && (
                      <p style={{ color: "#15616d" }}>{copySuccess}</p>
                    )}
                  </>
                </CSSTransition>
              )}
              <br />
              <br />
            </Grid>
          </Grid>
        </Container>
        <br />
      </Box>
    </>
  );
}

export default ShortNotes;
