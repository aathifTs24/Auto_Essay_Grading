import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import React, { useState } from "react";
import ShortNotes from "./Pages/ShortNotes/ShortNotes";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Dashboard from "./Pages/Dashboard";
import MCQs from "./Pages/MCQs/MCQs";
import EssayGrading from "./Pages/EssayGrading/EssayGrading";
import StoryTelling from "./Pages/StoryGeneration/StoryTelling";

function App() {
  return (
    <>
      <Header />
      <Router>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/short-notes" element={<ShortNotes />} />
          <Route path="/mcqs" element={<MCQs />} />
          <Route path="/essay-grading" element={<EssayGrading />} />
          <Route path="/story-generation" element={<StoryTelling />} />
        </Routes>
      </Router>
      <Footer />
    </>
  );
}

export default App;
