import React from "react";
import {
  Box,
  AppBar,
  Toolbar,
  IconButton,
  Button,
  Divider,
  Typography,
} from "@mui/material";
import { styled } from "@mui/system";
import image1 from "../Assets/logoimage.png";

const CustomAppBar = styled(AppBar)({
  background: "#15616d",
  height: "70px",
  boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)", // Add a subtle shadow
});

function Header(props) {
  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <CustomAppBar position="sticky">
          <Toolbar>
            <IconButton edge="start" color="inherit" aria-label="menu">
              <img
                src={image1}
                alt="Menu"
                style={{ width: "104px", height: "104px" }} // Rounded logo
              />
            </IconButton>

            <Button href="/" key={"login"} sx={{ color: "#eee" }}>
              <Typography
                variant="h4" // Larger text
                sx={{
                  textTransform: "none",
                  ml: 2,
                  fontSize: { xs: 16, sm: 24 }, // Increased font size
                  fontWeight: 700, // Bolder text
                  fontFamily: "cursive", // Custom font family
                }}
              >
                E-learning AI based Solution
              </Typography>
            </Button>

            <Box sx={{ flexGrow: 1 }} />
          </Toolbar>
        </CustomAppBar>
      </Box>
      <Divider />
    </>
  );
}

export default Header;
