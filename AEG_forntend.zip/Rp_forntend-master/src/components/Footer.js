import { Paper, Typography, Button, Divider, Grid, Box } from "@mui/material";
import MessageIcon from "@mui/icons-material/Message";

function Footer() {
  return (
    <>
      <Divider />
      <Grid
        square
        elevation={2}
        component={Paper}
        sx={{ py: 2, px: 1 }}
        container
        justifyContent={"center"}
        alignItems="center"
      >
        <Grid item xs={12} sm={9}>
          <Typography
            variant="subtitle2"
            textAlign={{ xs: "center", sm: "left" }}
          >
            © 2023, made with ❤️ by Reseach Team (2023-185) for a better
            Education . All copyrights reserved
          </Typography>
        </Grid>
        <Grid
          item
          xs={12}
          sm={3}
          textAlign={{ xs: "center", sm: "right" }}
          style={{ color: "#F9F6F2" }}
        >
          <Button endIcon={<MessageIcon />} variant="text" href="/contact-us">
            Contact Us
          </Button>
        </Grid>
      </Grid>
    </>
  );
}

export default Footer;
