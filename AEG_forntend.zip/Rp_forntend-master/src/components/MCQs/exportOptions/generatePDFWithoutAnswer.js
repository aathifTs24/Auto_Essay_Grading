import jsPDF from 'jspdf';

const generatePDFWithoutAnswer = (queAndAnsPair,{setAlertMessage,setSeverity,setOpenSnackbar}) => {
    console.log(queAndAnsPair)
    const doc = new jsPDF();
    doc.setFontSize(16); // Set the font size for the heading
    const headingText = "Answer the Question";
    const headingWidth = doc.getStringUnitWidth(headingText) * doc.internal.getFontSize() / doc.internal.scaleFactor;
    const xCoordinate = (doc.internal.pageSize.getWidth() - headingWidth) / 2;
    doc.text(headingText, xCoordinate, 20);

    // Add a line to separate the heading from the content
    doc.setLineWidth(0.5);
    doc.line(20, 25, doc.internal.pageSize.getWidth() - 20, 25); // Draw a line below the heading

    queAndAnsPair.forEach((queAndAns, index) => {
        doc.setFontSize(12);
        doc.text(`${index + 1}. ${queAndAns.question}`, 10, (index + 2) * 20);
        doc.setFontSize(10);
        doc.text(`Ans. ${'________________________________________________'}`, 15, (index + 2) * 20 + 8);
    });

    const document = doc.save('examPaper.pdf');
    if(document){
        setAlertMessage('PDF has been downloaded')
        setSeverity('success')
        setOpenSnackbar(true)
    }else{
        setAlertMessage("Error! couldn't download")
        setSeverity('error')
        setOpenSnackbar(true)
    }
};

export default generatePDFWithoutAnswer