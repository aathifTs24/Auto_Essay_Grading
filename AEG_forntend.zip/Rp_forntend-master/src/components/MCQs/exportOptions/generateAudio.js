import axios from 'axios'

const GenerateAudio = (queAndAnsPair, { setAlertMessage, setSeverity, setOpenSnackbar }) => {
    const formatData = (queAndAnsPair) => {
        let formattedData = '';
        formattedData += `Write the correct answer for each question\n\n\n\n`;
        queAndAnsPair.forEach((item, index) => {
            formattedData += `Question ${index + 1}: ${item.question}\n\n`;
        });

        return formattedData;
    }

    const downloadAudio = async () => {
        const formattedParagraph = await formatData(queAndAnsPair);
        console.log(formattedParagraph)

        setAlertMessage('Audio getting Download please wait');
        setSeverity('info');
        setOpenSnackbar(true);
    
        axios.post('http://127.0.0.1:8000/generate_audio/', { context: formattedParagraph, number:1 }, { responseType: 'blob' })
          .then((res) => {
            const blob = new Blob([res.data], { type: 'audio/mpeg' });
    
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = URL.createObjectURL(blob);
            a.download = 'audio.mp3';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
    
            URL.revokeObjectURL(a.href);
    
            setAlertMessage('Audio has been downloaded');
            setSeverity('success');
            setOpenSnackbar(true);
          })
          .catch((err) => {
            console.error(err);
          });
      };

      downloadAudio()
}

export default GenerateAudio
