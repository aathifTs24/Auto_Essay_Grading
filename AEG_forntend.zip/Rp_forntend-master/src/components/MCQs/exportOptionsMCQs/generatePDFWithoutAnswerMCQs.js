import jsPDF from 'jspdf';

const generatePDFWithoutAnswerMCQs = (mcqs, { setAlertMessage, setSeverity, setOpenSnackbar }) => {
    const doc = new jsPDF();
    doc.setFontSize(16); // Set the font size for the heading
    const headingText = "Quiz - Underile the correct answer";
    const headingWidth = doc.getStringUnitWidth(headingText) * doc.internal.getFontSize() / doc.internal.scaleFactor;
    const xCoordinate = (doc.internal.pageSize.getWidth() - headingWidth) / 2;
    doc.text(headingText, xCoordinate, 20);

    // Add a line to separate the heading from the content
    doc.setLineWidth(0.5);
    doc.line(20, 25, doc.internal.pageSize.getWidth() - 20, 25); // Draw a line below the heading

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]]; // Swap elements
        }
    }

    // Function to capitalize the first letter of each word in a string
    // const capitalizeWords = str => {
    //     return str.replace(/\b\w/g, firstChar => firstChar.toUpperCase());
    // };

    // Function to capitalize the first letter of a sentence
    const capitalizeSentence = str => {
        return str.replace(/(^\w{1})|(\.\s*\w{1})/g, match => match.toUpperCase());
    };


    mcqs.forEach((mcq, index) => {
        const options = [...mcq.distractors, mcq.answer]; // Combine answer and distractors
        shuffleArray(options); // Shuffle the array

        doc.setFontSize(12);
        doc.text(`${index + 1}. ${mcq.question}`, 10, (index + index + 2) * 20);
        doc.setFontSize(10);
        doc.text(`A. ${capitalizeSentence(options[0])}`, 15, (index + index + 2) * 20 + 6);
        doc.setFontSize(10);
        doc.text(`B. ${capitalizeSentence(options[1])}`, 15, (index + index + 2) * 20 + 11);
        doc.setFontSize(10);
        doc.text(`C. ${capitalizeSentence(options[2])}`, 15, (index + index + 2) * 20 + 16);
        doc.setFontSize(10);
        doc.text(`D. ${capitalizeSentence(options[3])}`, 15, (index + index + 2) * 20 + 21);

    });

    const document = doc.save('mcqs-examPaper.pdf');
    if (document) {
        setAlertMessage('PDF has been downloaded')
        setSeverity('success')
        setOpenSnackbar(true)
    } else {
        setAlertMessage("Error! couldn't download")
        setSeverity('error')
        setOpenSnackbar(true)
    }
};

export default generatePDFWithoutAnswerMCQs