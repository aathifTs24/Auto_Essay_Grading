import axios from 'axios'

const GenerateAudioMCQs = (mcqs, { setAlertMessage, setSeverity, setOpenSnackbar }) => {
    
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]]; // Swap elements
        }
    }
    const formatData = (mcqs) => {
        let formattedData = '';

        mcqs.forEach((item, index) => {
            const options = [...item.distractors, item.answer]; // Combine answer and distractors
            shuffleArray(options); // Shuffle the array

            formattedData += `Question ${index + 1}: ${item.question}\n`;
            formattedData += `A: ${options[0]}\n\n`;
            formattedData += `B: ${options[1]}\n\n`;
            formattedData += `C: ${options[2]}\n\n`;
            formattedData += `D: ${options[3]}\n\n`;
        });
        return formattedData;
    }

    const downloadAudio = async () => {
        const formattedParagraph = await formatData(mcqs);
        console.log(formattedParagraph)

        setAlertMessage('Audio getting Download please wait');
        setSeverity('info');
        setOpenSnackbar(true);

        axios.post('http://127.0.0.1:8000/generate_audio/', { context: formattedParagraph, number:1 }, { responseType: 'blob' })
          .then((res) => {
            console.log(res.data)
            const blob = new Blob([res.data], { type: 'audio/mpeg' });
    
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = URL.createObjectURL(blob);
            a.download = 'audio.mp3';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
    
            URL.revokeObjectURL(a.href);
    
            setAlertMessage('Audio has been downloaded');
            setSeverity('success');
            setOpenSnackbar(true);
          })
          .catch((err) => {
            console.error(err);
          });
      };

      downloadAudio()
}

export default GenerateAudioMCQs
