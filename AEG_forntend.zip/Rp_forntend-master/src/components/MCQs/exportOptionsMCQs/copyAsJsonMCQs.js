
const copyAsJsonMCQs = (queAndAnsPair,{setAlertMessage,setSeverity,setOpenSnackbar}) => {
    const jsonString = JSON.stringify(queAndAnsPair, null, 2);
    navigator.clipboard.writeText(jsonString)
      .then(() => {
        setAlertMessage('Copied to clipboard as JSON')
        setSeverity('success')
        setOpenSnackbar(true)
      })
      .catch(() => {
        setAlertMessage("Error copying to clipboard")
        setSeverity('error')
        setOpenSnackbar(true)
      });
  };

export default copyAsJsonMCQs