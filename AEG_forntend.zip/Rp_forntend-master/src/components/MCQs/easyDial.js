import * as React from 'react';
import Box from '@mui/material/Box';
import SpeedDial from '@mui/material/SpeedDial';
import SaveAsIcon from '@mui/icons-material/SaveAs';
import SpeedDialAction from '@mui/material/SpeedDialAction';
import FileCopyIcon from '@mui/icons-material/FileCopyOutlined';
import NoteAltIcon from '@mui/icons-material/NoteAlt';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import generatePDF from './exportOptions/generatePDF';
import copyAsJSON from './exportOptions/copyAsJson';
import generatePDFWithoutAnswer from './exportOptions/generatePDFWithoutAnswer';
import RecordVoiceOverIcon from '@mui/icons-material/RecordVoiceOver';
import GenerateAudio from './exportOptions/generateAudio';

const actions = [
  { icon: <FileCopyIcon />, name: 'Copy as json' },
  { icon: <PictureAsPdfIcon />, name: 'Save as PDF' },
  { icon: <NoteAltIcon />, name: 'Save as exam paper (PDF)' },
  { icon: <RecordVoiceOverIcon />, name: 'Save as Audio' },
];

export default function BasicSpeedDial({queAndAnsPair,setAlertMessage,setSeverity,setOpenSnackbar}) {
    const handleSpeedDial=(name)=>{
        if(name === "Save as PDF"){
            generatePDF(queAndAnsPair,{setAlertMessage,setSeverity,setOpenSnackbar})
        }
        if(name === "Copy as json"){
            copyAsJSON(queAndAnsPair,{setAlertMessage,setSeverity,setOpenSnackbar})
        }
        if(name === "Save as exam paper (PDF)"){
            generatePDFWithoutAnswer(queAndAnsPair,{setAlertMessage,setSeverity,setOpenSnackbar})
        }
        if(name === "Save as Audio"){
            GenerateAudio(queAndAnsPair,{setAlertMessage,setSeverity,setOpenSnackbar})
        }
    }
  return (
    <Box sx={{ height: 320, transform: 'translateZ(0px)', flexGrow: 1 }}>
      <SpeedDial
        ariaLabel="SpeedDial basic example"
        sx={{ position: 'absolute', bottom: 52, right: 16 }}
        icon={<SaveAsIcon />}
      >
        {actions.map((action) => (
          <SpeedDialAction
            key={action.name}
            icon={action.icon}
            tooltipTitle={action.name}
            onClick={()=>handleSpeedDial(action.name)}
          />
        ))}
      </SpeedDial>
    </Box>
  );
}