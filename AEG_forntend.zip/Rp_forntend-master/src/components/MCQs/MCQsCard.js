import React, { useEffect } from 'react'
import { Button, Typography,Box,Dialog,DialogActions,DialogContentText,DialogContent  } from '@mui/material'
import EditNoteIcon from '@mui/icons-material/EditNote';
import DeleteIcon from '@mui/icons-material/Delete';
import BasicSpeedDialMCQs from './easyDialMCQs';
import Modal from '@mui/material/Modal';
import TextField from '@mui/material/TextField';
import { useState } from 'react';
import DescriptionAlerts from './Alert';
import BasicSelect from './distractorChoice';

const MCQsCard = ({ isMcqsGenerated, generatedMCQs,setGeneratedMCQs }) => {
    const [editIndex, setEditIndex] = useState();
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [severity, setSeverity] = useState('')
    const [alertMessage, setAlertMessage] = useState('')
    const [editedQuestion, setEditedQuestion] = useState('');
    const [editedAnswer, setEditedAnswer] = useState('');
    const [mcqs,setMcqs] = useState([])
    const [editedDistractor1, setEditedDistractor1] = useState('');
    const [editedDistractor2, setEditedDistractor2] = useState('');
    const [editedDistractor3, setEditedDistractor3] = useState('');
    const [deleteId, setDeleteId] = useState('')
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
    const [dist,setDist] = useState([])

    useEffect(()=>{
        if(generatedMCQs.length !== 0){
        const modifiedMcqs = generatedMCQs.map(mcq => ({
            question: mcq.question,
            answer: mcq.answer,
            distractors: mcq.distractors.slice(0, 3) // Select the first 3 distractors
        }));
            setMcqs(modifiedMcqs)
        }
    },[generatedMCQs])

    const handleDelete = () => {
        try{
        const updatedMcqs = [...mcqs];
        updatedMcqs.splice(deleteId, 1);
        setMcqs(updatedMcqs);

        const updatedGeneratedMcqs = [...generatedMCQs];
        updatedGeneratedMcqs.splice(deleteId, 1);
        setGeneratedMCQs(updatedGeneratedMcqs);

        handleCloseDelete()
        setAlertMessage('Deleted')
        setSeverity('success')
        setOpenSnackbar(true)

        }catch{
        setAlertMessage("Error! couldn't delete")
        setSeverity('error')
        setOpenSnackbar(true)
        }
      };

      const handleOpenEditModal = async(index) => {
        console.log(generatedMCQs)
        setEditIndex(index);
        setEditedQuestion(mcqs[index].question);
        setEditedAnswer(mcqs[index].answer);
        setEditedDistractor1(mcqs[index].distractors[0])
        setEditedDistractor2(mcqs[index].distractors[1])
        setEditedDistractor3(mcqs[index].distractors[2])
        setDist(generatedMCQs[index].distractors)
        setEditModalOpen(true);
        setTimeout(() => {
        }, 3000);
      };
    
    const handleCloseEditModal = () => {
        setEditIndex('');
        setDist([])
        setEditModalOpen(false);
      };
    
    const deleteButtonClicked = (index) => {
        setDeleteId(index)
        handleOpenDelete()
    }

    const handleOpenDelete = () => {
      setDeleteDialogOpen(true)
    }

    const handleCloseDelete = () => {
      setDeleteDialogOpen(false)
      setDeleteId('')
    }
    
    const handleSaveEdit = () => {
        if (editIndex !== null) {
          const updatedMcqs = [...mcqs];
          updatedMcqs[editIndex].question = editedQuestion;
          updatedMcqs[editIndex].answer = editedAnswer;
          updatedMcqs[editIndex].distractors[0] = editedDistractor1;
          updatedMcqs[editIndex].distractors[1] = editedDistractor2;
          updatedMcqs[editIndex].distractors[2] = editedDistractor3;
          setMcqs(updatedMcqs);
          handleCloseEditModal();
          setAlertMessage('Saved')
          setSeverity('success')
          setOpenSnackbar(true)
        }else{
          setAlertMessage("Error! editIndex is null")
        setSeverity('error')
        setOpenSnackbar(true)
        }
      };
    
    const handleCloseSnackbar = () => {
        setOpenSnackbar(false);
    };
    
    return (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', justifyContent: 'center' }}>
        <div>    
        <DescriptionAlerts openSnackbar={openSnackbar} handleCloseSnackbar={handleCloseSnackbar} severity={severity} alertMessage={alertMessage} />
            {isMcqsGenerated && (
                <div>
                <Typography
                    sx={{
                    textTransform: "none",
                    mt: '10px',
                    mb: '10px',
                    textAlign: 'center',
                    fontSize: { xs: 16, sm: 24 },
                    fontWeight: 700,
                    fontFamily: "cursive",
                    }}
                >
                    Generated multiple-choice question
                 </Typography>
                    <hr />
                    {mcqs.map((mcq, index) => (
                        <div key={index} style={{
                            maxWidth: '100%',
                            marginTop: '20px',
                            paddingTop: '10px',
                            paddingBottom: '10px',
                            paddingLeft: '10px'
                        }}>
                            <Typography
                                fontSize={20}
                                fontFamily='Monospace'
                                fontWeight='medium'>
                                {index + 1}.{mcq.question}
                            </Typography>
                            <Typography
                                textTransform='capitalize'
                                fontSize={17}
                                fontFamily='Monospace'
                                color='green'
                                fontWeight='bold'>
                                {"A. "+mcq.answer}
                            </Typography>
                            <Typography
                                textTransform='capitalize'
                                fontSize={17}
                                fontFamily='Monospace'
                                fontWeight='light'>
                                {"B. "+mcq.distractors[0]}
                            </Typography>
                            <Typography
                                textTransform='capitalize'
                                fontSize={17}
                                fontFamily='Monospace'
                                fontWeight='light'>
                                {"C. "+mcq.distractors[1]}
                            </Typography>
                            <Typography
                                textTransform='capitalize'
                                fontSize={17}
                                fontFamily='Monospace'
                                fontWeight='light'>
                                {"D. "+mcq.distractors[2]}
                            </Typography>
                            <Button onClick={() => handleOpenEditModal(index)}><EditNoteIcon style={{color:'green'}}/></Button>
              <Button onClick={() => deleteButtonClicked(index)}><DeleteIcon style={{color:'red'}}/></Button>
                            <div style={{ boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)', padding: '10px' }}>
                                <hr style={{ border: 'none', borderBottom: '1px solid #ccc' }} />
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
        <div style={{ position: 'fixed', bottom: '20px', right: '20px', zIndex: 999 }}>
                <BasicSpeedDialMCQs mcqs={mcqs}
                setOpenSnackbar={setOpenSnackbar}
                setSeverity={setSeverity}
                setAlertMessage={setAlertMessage}/>
            </div>

            {/* Edit Modal */}
      <Modal open={editModalOpen} onClose={handleCloseEditModal}>
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '20px', borderRadius:'5px'}}>
        <Typography
          sx={{
            textTransform: "none",
            mt: '10px',
            mb: '10px',
            textAlign: 'center',
            fontSize: { xs: 16, sm: 24 },
            fontWeight: 700,
            fontFamily: "cursive",
          }}
        >
          Edit Multiple Choice Question
        </Typography>
          <TextField label="Question" 
          fullWidth value={editedQuestion} 
          onChange={(e) => setEditedQuestion(e.target.value)} />
          <TextField label="Answer" 
          fullWidth value={editedAnswer}
          style={{marginTop:'15px',marginBottom:'15px'}}
          onChange={(e) => setEditedAnswer(e.target.value)} />
          <Box sx={{display:'flex', marginTop:'15px', marginBottom:'15px'}}>
          <TextField label="Distractor1" 
          fullWidth value={editedDistractor1}
          sx={{mr:'10px'}}
          onChange={(e) => setEditedDistractor1(e.target.value)} />
          <BasicSelect distractors={dist} setEditedDistractor={setEditedDistractor1}/>
          </Box>
          <Box sx={{display:'flex', marginTop:'15px', marginBottom:'15px'}}>
          <TextField label="Distractor2" 
          fullWidth value={editedDistractor2}
          sx={{mr:'10px'}}
          onChange={(e) => setEditedDistractor2(e.target.value)} />
          <BasicSelect distractors={dist} setEditedDistractor={setEditedDistractor2}/>
          </Box>
          <Box sx={{display:'flex', marginTop:'15px', marginBottom:'15px'}}>
          <TextField label="Distractor3" 
          fullWidth value={editedDistractor3}
          sx={{mr:'10px'}}
          onChange={(e) => setEditedDistractor3(e.target.value)} />
          <BasicSelect distractors={dist} setEditedDistractor={setEditedDistractor3}/>
          </Box>
          <Button onClick={handleSaveEdit} sx={{
                                backgroundColor: '#50C878',
                                color: 'white',
                                width: '48%',
                                mr:'4%',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#00A36C',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }}>Save</Button>
          <Button onClick={handleCloseEditModal} sx={{
                                backgroundColor: 'red',
                                width: '48%',
                                color: 'white',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#D22B2B',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }}>Cancel</Button>
        </div>
      </Modal>

      {/* delete Confirm Modal */}
      <Box>
                <Dialog open={deleteDialogOpen} onClose={handleCloseDelete}>
                    <DialogContent sx={{ mt: '10px', }}>
                        <DialogContentText >
                            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

                            </Box>
                            Are you sure!
                            Do you want to delete this Question and answer pair?
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button
                            sx={{
                                backgroundColor: 'red',
                                width: '50%',
                                color: 'white',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#D22B2B',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }} onClick={handleCloseDelete}>No! Don't</Button>
                        <Button
                            sx={{
                                backgroundColor: '#50C878',
                                color: 'white',
                                width: '50%',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#00A36C',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }}
                            onClick={handleDelete}
                        >Yes, please</Button>
                    </DialogActions>
                </Dialog>
            </Box>
</div>
)}

export default MCQsCard





//   <Card sx={{maxWidth:'100%',
                        //   boxShadow:'0px 4px 6px rgba(0, 0, 0, 0.1)',
                        //   marginTop:'20px',
                        //   paddingTop:'10px',
                        //   paddingTop:'10px',
                        //   paddingBottom:'10px',
                        //   paddingLeft:'10px'
                        //   }} key={index}>
                        //     <CardContent>
                        //         <Typography 
                        //         textTransform='capitalize'
                        //         fontSize={20}
                        //         fontFamily='Monospace'
                        //         fontWeight='medium'>
                        //             {index+1}.{mcq.question}
                        //         </Typography>
                        //         <Typography 
                        //         textTransform='capitalize'
                        //         fontSize={17}
                        //         fontFamily='Monospace'
                        //         fontWeight='light'>
                        //             {<CircleIcon style={{fontSize:'13px', marginRight: '5px'}}/>}{mcq.answer}
                        //         </Typography>
                        //     </CardContent>
                        //   </Card>
