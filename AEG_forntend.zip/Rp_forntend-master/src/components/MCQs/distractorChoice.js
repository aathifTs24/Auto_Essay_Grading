import React from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

export default function BasicSelect({distractors, setEditedDistractor}) {

  const handleChange = (event) => {
    setEditedDistractor(event.target.value);
  };

  return (
    <Box sx={{ minWidth: 120, maxWidth:120 }}>
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Distractors</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          label="distractor"
          onChange={handleChange}
        >
          {distractors.map((distractor)=>(
            <MenuItem value={distractor}>{distractor}</MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
}