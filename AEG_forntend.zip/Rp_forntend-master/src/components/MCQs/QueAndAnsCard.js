import React from 'react'
import { Button, Typography,Box,Dialog,DialogActions,DialogContentText,DialogContent  } from '@mui/material'
import EditNoteIcon from '@mui/icons-material/EditNote';
import DeleteIcon from '@mui/icons-material/Delete';
import CircleIcon from '@mui/icons-material/Circle';
import BasicSpeedDial from './easyDial';
import Modal from '@mui/material/Modal';
import TextField from '@mui/material/TextField';
import { useState } from 'react';
import DescriptionAlerts from './Alert';


const QueAndAnsCard = ({ isQueAndAnsPairGenerated, queAndAnsPair,setQueAndAnsPair }) => {
    const [editIndex, setEditIndex] = useState(null);
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [severity, setSeverity] = useState('')
    const [alertMessage, setAlertMessage] = useState('')
    const [editedQuestion, setEditedQuestion] = useState('');
    const [editedAnswer, setEditedAnswer] = useState('');
    const [deleteId, setDeleteId] = useState('')
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)

    const handleDelete = () => {
        try{const updatedQueAndAnsPair = [...queAndAnsPair];
        updatedQueAndAnsPair.splice(deleteId, 1);
        setQueAndAnsPair(updatedQueAndAnsPair);
        handleCloseDelete()
        setAlertMessage('Deleted')
          setSeverity('success')
          setOpenSnackbar(true)
        }catch{
        setAlertMessage("Error! couldn't delete")
        setSeverity('error')
        setOpenSnackbar(true)
        }
      };

      const handleOpenEditModal = (index) => {
        setEditIndex(index);
        setEditedQuestion(queAndAnsPair[index].question);
        setEditedAnswer(queAndAnsPair[index].answer);
        setEditModalOpen(true);
      };
    
    const handleCloseEditModal = () => {
        setEditIndex(null);
        setEditModalOpen(false);
      };
    
    const deleteButtonClicked = (index) => {
        setDeleteId(index)
        handleOpenDelete()
    }

    const handleOpenDelete = () => {
      setDeleteDialogOpen(true)
    }

    const handleCloseDelete = () => {
      setDeleteDialogOpen(false)
      setDeleteId('')
    }
    
    const handleSaveEdit = () => {
        if (editIndex !== null) {
          const updatedQueAndAnsPair = [...queAndAnsPair];
          updatedQueAndAnsPair[editIndex].question = editedQuestion;
          updatedQueAndAnsPair[editIndex].answer = editedAnswer;
          setQueAndAnsPair(updatedQueAndAnsPair);
          handleCloseEditModal();
          setAlertMessage('Saved')
          setSeverity('success')
          setOpenSnackbar(true)
        }else{
          setAlertMessage("Error! editIndex is null")
        setSeverity('error')
        setOpenSnackbar(true)
        }
      };
    
    const handleCloseSnackbar = () => {
        setOpenSnackbar(false);
    };
    
    return (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', justifyContent: 'center' }}>
        <div>    
        <DescriptionAlerts openSnackbar={openSnackbar} handleCloseSnackbar={handleCloseSnackbar} severity={severity} alertMessage={alertMessage} />
            {isQueAndAnsPairGenerated && (
                <div>
                    <Typography
                    sx={{
                    textTransform: "none",
                    mt: '10px',
                    mb: '10px',
                    textAlign: 'center',
                    fontSize: { xs: 16, sm: 24 },
                    fontWeight: 700,
                    fontFamily: "cursive",
                    }}
                >
                    Generated question and answer pairs
                 </Typography>
                    <hr />
                    {queAndAnsPair.map((queAndAns, index) => (
                        <div key={index} style={{
                            maxWidth: '100%',
                            marginTop: '20px',
                            paddingTop: '10px',
                            paddingBottom: '10px',
                            paddingLeft: '10px'
                        }}>
                            <Typography
                                fontSize={20}
                                fontFamily='Monospace'
                                fontWeight='medium'>
                                {index + 1}.{queAndAns.question}
                            </Typography>
                            <Typography
                                textTransform='capitalize'
                                fontSize={17}
                                fontFamily='Monospace'
                                fontWeight='light'>
                                {<CircleIcon style={{ fontSize: '13px', marginRight: '5px' }} />}{queAndAns.answer}
                            </Typography>
                            <Button onClick={() => handleOpenEditModal(index)}><EditNoteIcon style={{color:'green'}}/></Button>
              <Button onClick={() => deleteButtonClicked(index)}><DeleteIcon style={{color:'red'}}/></Button>
                            <div style={{ boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)', padding: '10px' }}>
                                <hr style={{ border: 'none', borderBottom: '1px solid #ccc' }} />
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
        <div style={{ position: 'fixed', bottom: '20px', right: '20px', zIndex: 999 }}>
                <BasicSpeedDial queAndAnsPair={queAndAnsPair}
                setOpenSnackbar={setOpenSnackbar}
                setSeverity={setSeverity}
                setAlertMessage={setAlertMessage}/>
            </div>

            {/* Edit Modal */}
      <Modal open={editModalOpen} onClose={handleCloseEditModal} >
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '20px', borderRadius:'5px' }}>
        <Typography
          sx={{
            textTransform: "none",
            mt: '10px',
            mb: '10px',
            textAlign: 'center',
            fontSize: { xs: 16, sm: 24 },
            fontWeight: 700,
            fontFamily: "cursive",
          }}
        >
          Edit Question and Answer Pair
        </Typography>
          <TextField label="Question" 
          fullWidth value={editedQuestion} 
          onChange={(e) => setEditedQuestion(e.target.value)} />
          <TextField label="Answer" 
          fullWidth value={editedAnswer}
          style={{marginTop:'15px',marginBottom:'15px'}}
          onChange={(e) => setEditedAnswer(e.target.value)} />
          <Button onClick={handleSaveEdit} sx={{
                                backgroundColor: '#50C878',
                                color: 'white',
                                width: '48%',
                                mr:'4%',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#00A36C',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }}>Save</Button>
          <Button onClick={handleCloseEditModal} sx={{
                                backgroundColor: 'red',
                                width: '48%',
                                color: 'white',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#D22B2B',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }}>Cancel</Button>
        </div>
      </Modal>

      {/* delete Confirm Modal */}
      <Box>
                <Dialog open={deleteDialogOpen} onClose={handleCloseDelete}>
                    <DialogContent sx={{ mt: '10px', }}>
                        <DialogContentText >
                            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

                            </Box>
                            Are you sure!
                            Do you want to delete this Question and answer pair?
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button
                            sx={{
                                backgroundColor: 'red',
                                width: '50%',
                                color: 'white',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#D22B2B',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }} onClick={handleCloseDelete}>No! Don't</Button>
                        <Button
                            sx={{
                                backgroundColor: '#50C878',
                                color: 'white',
                                width: '50%',
                                textTransform:'capitalize',
                                ":hover": {
                                    backgroundColor: '#00A36C',
                                    color: 'white',
                                    cursor: 'pointer'
                                },
                            }}
                            onClick={handleDelete}
                        >Yes, please</Button>
                    </DialogActions>
                </Dialog>
            </Box>
</div>
)}

export default QueAndAnsCard





//   <Card sx={{maxWidth:'100%',
                        //   boxShadow:'0px 4px 6px rgba(0, 0, 0, 0.1)',
                        //   marginTop:'20px',
                        //   paddingTop:'10px',
                        //   paddingTop:'10px',
                        //   paddingBottom:'10px',
                        //   paddingLeft:'10px'
                        //   }} key={index}>
                        //     <CardContent>
                        //         <Typography 
                        //         textTransform='capitalize'
                        //         fontSize={20}
                        //         fontFamily='Monospace'
                        //         fontWeight='medium'>
                        //             {index+1}.{queAndAns.question}
                        //         </Typography>
                        //         <Typography 
                        //         textTransform='capitalize'
                        //         fontSize={17}
                        //         fontFamily='Monospace'
                        //         fontWeight='light'>
                        //             {<CircleIcon style={{fontSize:'13px', marginRight: '5px'}}/>}{queAndAns.answer}
                        //         </Typography>
                        //     </CardContent>
                        //   </Card>
