import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
// import AlertTitle from '@mui/material/AlertTitle';
import Stack from '@mui/material/Stack';

export default function DescriptionAlerts({ openSnackbar, handleCloseSnackbar,severity,alertMessage }) {
  
  // Use a state variable to track whether the Snackbar should stay open
  const [stayOpen, setStayOpen] = React.useState(false);

  // Handle changes in the 'severity' prop
  React.useEffect(() => {
    if (severity === 'info') {
      // If severity is 'info', set 'stayOpen' to true
      setStayOpen(true);
    }
  }, [severity]);

  // Calculate the autoHideDuration based on the 'stayOpen' state
  const autoHideDuration = stayOpen ? null : 3000;

  return (
    <Snackbar
      open={openSnackbar}
      autoHideDuration={autoHideDuration}
      onClose={handleCloseSnackbar}
      onExited={() => {
        // Reset 'stayOpen' when the Snackbar is closed
        setStayOpen(false);
      }}
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
    >
      <Stack sx={{ width: '100%', justifyContent: 'center', alignItems: 'center' }} spacing={2}>
        <Alert severity={severity}>
          {alertMessage}
        </Alert>
      </Stack>
    </Snackbar>
  );
}
