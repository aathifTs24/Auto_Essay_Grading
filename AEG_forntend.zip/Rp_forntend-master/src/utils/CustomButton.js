import React from "react";
import { Button } from "@mui/material";
import { styled } from "@mui/system";

const CustomButton = styled(Button)(({ theme }) => ({
  marginTop: theme.spacing(2),
  marginRight: theme.spacing(1),
  animation: "$clickAnimation 0.25s ease-in-out",
  background: "#15616d",
  // background: "#2196F3",
  color: "#FFFFFF", // White text color
  boxShadow: "0 5px 10px 15616d",
  borderRadius: "5px", // Rounded corners
  transition: "background 0.3s ease-in-out", // Smooth background transition

  "&:hover": {
    background: "#81b29a",
    transform: "scale(1.02)",
  },

  "@keyframes clickAnimation": {
    "0%": { transform: "scale(1)" },
    "50%": { transform: "scale(1.05)" },
    "100%": { transform: "scale(1)" },
  },
}));

export default CustomButton;
